# Stage 4 — Restaurant Admin

Implemented backend modules:
- Restaurant settings: name, slug, phone, address, logo, currency, default language
- Category CRUD
- Menu item CRUD with category ownership validation
- Table CRUD, unique table number per restaurant, QR token generation
- Staff list/create/update with allowed roles
- Restaurant dashboard counts
- Audit logs for admin mutations

Security: every admin query and mutation is scoped by authenticated `restaurant_id`; blocked/deleted restaurants are denied.
