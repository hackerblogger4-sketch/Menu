# Stage 5 — Super Admin / Developer

Implemented backend modules:
- Platform statistics
- Restaurant list/detail/create/update
- Restaurant status control: ACTIVE / RESTRICTED / BLOCKED / DELETED
- Block reason and optional block expiration
- Restaurant user inspection
- Audit log browsing with restaurant filter
- Platform settings: name, maintenance mode, default currency, new-restaurant switch

Security: Super Admin role is required. BLOCKED and DELETED remain distinct, and public/customer/order/WebSocket access is blocked server-side.
