# Stage 2 — QR Menu + QR Validation

Implemented:
- Public QR table token lookup
- Restaurant status validation before serving menu
- Public menu API
- Active table validation
- Available menu item filtering
- Restaurant/table context in menu response
- Secure QR token regeneration for restaurant owner/admin
- QR PNG endpoint
- Audit log for QR regeneration
- Android customer panel accepts `qrrestaurant://table?...` deep-link context
- Internet permission

API:
GET /api/v1/public/tables/{token}/menu
GET /api/v1/public/tables/{token}/qr.png
POST /api/v1/restaurant/tables/{table_id}/qr

Security:
- Invalid/inactive QR tokens are rejected.
- BLOCKED and DELETED restaurants are rejected.
- Restaurant-scoped QR regeneration checks the authenticated user's restaurant.
- QR tokens are random and can be regenerated.

Note:
The Android customer UI is intentionally still a foundation. Full network-driven menu rendering and cart/order submission belong to Stage 3+.
