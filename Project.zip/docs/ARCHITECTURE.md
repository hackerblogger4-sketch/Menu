# Architecture
Android client has four panel entry points. Backend must remain authoritative for authentication, RBAC, restaurant ownership, prices, order totals and blocked status.
Multi-tenant rule: every restaurant-scoped request is checked against the authenticated user's restaurant; only SUPER_ADMIN can cross restaurant boundaries.
Future stages: FastAPI + PostgreSQL, QR validation, order/WebSocket, Restaurant Admin CRUD, Super Admin block/unblock + audit, notifications, analytics and production deployment.
