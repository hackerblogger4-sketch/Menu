# Production deployment checklist

1. Copy `.env.example` to a secure production environment and set:
   - `JWT_SECRET` to a long random secret.
   - `POSTGRES_PASSWORD` to a unique strong password.
   - `DATABASE_URL` to the production PostgreSQL URL.
   - `CORS_ORIGINS` to only trusted web origins.
2. Put TLS certificates in `infra/nginx/certs/` and configure the Nginx HTTPS server block before exposing port 443.
3. Start: `docker compose -f docker-compose.prod.yml up -d --build`.
4. Verify `/api/v1/health/live` and `/api/v1/health/ready`.
5. Verify `alembic upgrade head` completed in backend logs.
6. Configure scheduled execution of `scripts/backup_postgres.sh` and retain multiple backup generations off-host.
7. Keep the backend behind Nginx/firewall; do not expose PostgreSQL publicly.
8. Rotate JWT/database credentials if they were ever committed or shared.
