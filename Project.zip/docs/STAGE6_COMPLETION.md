# Stage 6 — Notifications + Analytics

Implemented:
- In-app staff notifications for new orders.
- Notification list, unread filter, read/unread mutation with tenant isolation.
- Restaurant analytics: totals, today, revenue, status counts, top items.
- Super-admin platform analytics: today's orders/revenue and restaurant status counts.
- Notification migration `0004_notifications`.
