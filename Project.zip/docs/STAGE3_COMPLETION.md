# Stage 3 — Orders + Real-time Order Panel

Implemented:
- Customer QR order creation: `POST /api/v1/public/tables/{token}/orders`
- Server-side price, availability, restaurant/table ownership validation.
- Order snapshots preserve item name and price at order time.
- Order number per restaurant and idempotency key protection.
- Order statuses: `new`, `accepted`, `preparing`, `ready`, `delivered`, `completed`, `cancelled`.
- Restaurant-scoped order list for owner/admin/operator/kitchen roles.
- Restaurant-scoped status update endpoint.
- Audit logs for order creation and status changes.
- WebSocket endpoint: `/api/v1/restaurant/orders/ws?token=<JWT>`.
- WebSocket connections are isolated by `restaurant_id`; blocked/deleted restaurants are rejected.
- Android Order Panel foundation updated for Stage 3 API/WebSocket endpoints.
- Alembic migration `0002_orders`.

Security boundary: client prices are never trusted; the backend reads current menu prices and recalculates totals.
