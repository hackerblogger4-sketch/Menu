# Stage 7 — Security Hardening + Production Readiness

Implemented:
- Request ID response header.
- Security headers: nosniff, frame deny, referrer policy, permissions policy, no-store.
- HSTS when `ENVIRONMENT=production`.
- Configurable CORS allow-list.
- In-process IP rate limiting and request-body size guard.
- Liveness and database readiness endpoints.
- Production Docker Compose with Postgres healthcheck and non-root backend container.
- Nginx reverse proxy with WebSocket upgrade support.
- PostgreSQL backup script.
- CI Android build remains configured with Gradle 8.11.1.

Before public launch, set strong secrets, configure CORS to real domains, provide TLS certificates/HTTPS at the reverse proxy, configure firewall/backups/monitoring, and run migrations against the production database.
