#!/usr/bin/env sh
set -eu
: "${DATABASE_URL:?DATABASE_URL required}"
mkdir -p backups
# Expected format: postgresql+psycopg://user:password@host:5432/db
URL="${DATABASE_URL#postgresql+psycopg://}"
CREDS_HOST="${URL%%@*}"; HOST_DB="${URL#*@}"; USER="${CREDS_HOST%%:*}"; PASS="${CREDS_HOST#*:}"; HOST="${HOST_DB%%/*}"; DB="${HOST_DB#*/}"
TS=$(date -u +%Y%m%dT%H%M%SZ)
PGPASSWORD="$PASS" pg_dump -h "${HOST%:*}" -p "${HOST#*:}" -U "$USER" -Fc "$DB" > "backups/qrrestaurant-$TS.dump"
echo "backup created: backups/qrrestaurant-$TS.dump"
