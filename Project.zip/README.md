# QR Restaurant Platform V3

Android/Kotlin foundation for a multi-restaurant QR ordering SaaS.

Panels: Customer Menu, Order Panel, Restaurant Admin, Super Admin/Developer.
Backend authority is required for authentication, RBAC, restaurant isolation, pricing and blocking.

Open this folder in Android Studio. Next stages add FastAPI/PostgreSQL, QR validation, orders/WebSocket, admin CRUD and Super Admin controls.


## Stage 1 status
Stage 1 foundation is implemented. Automated security tests pass locally (2/2).
The Android build is configured to use Gradle 8.11.1 in GitHub Actions.
The backend Docker service runs Alembic migrations before starting FastAPI.

## Stage 3
Orders and real-time Order Panel are implemented. See `docs/STAGE3_COMPLETION.md`.

## Stage 4
Restaurant Admin CRUD is implemented: categories, menu items, tables/QR, staff roles, restaurant settings and restaurant statistics. All endpoints enforce restaurant isolation and RBAC.

## Stage 5
Super Admin / Developer controls are implemented: platform statistics, restaurant create/update/list/detail, restaurant user inspection, block/unblock/delete status control, audit log browsing and platform settings. Restaurant blocking remains backend-enforced and is distinct from soft deletion.


## Stage 6
Notifications and restaurant/platform analytics are implemented.

## Stage 7
Security hardening and production deployment assets are implemented. See `docs/STAGE7_COMPLETION.md` and `docs/DEPLOYMENT.md`.

## Launch status
The project is **deployment-prepared**, not a hosted production service. Before launch, configure real secrets, domain/CORS, TLS, backups, monitoring and production infrastructure.
