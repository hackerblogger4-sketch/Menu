import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from app.db.session import SessionLocal
from app.models import Restaurant, User, UserRole
from app.auth.security import hash_password

db=SessionLocal()
try:
    if not db.query(User).filter_by(email='superadmin@example.com').first():
        r=Restaurant(name='Demo Restaurant',slug='demo-restaurant')
        db.add(r); db.flush()
        db.add(User(name='Super Admin',email='superadmin@example.com',password_hash=hash_password('ChangeMe123!'),role=UserRole.SUPER_ADMIN,restaurant_id=None))
        db.add(User(name='Restaurant Owner',email='owner@example.com',password_hash=hash_password('ChangeMe123!'),role=UserRole.RESTAURANT_OWNER,restaurant_id=r.id))
        db.commit(); print('Seeded demo users. Change passwords before production.')
    else: print('Seed already exists.')
finally: db.close()
