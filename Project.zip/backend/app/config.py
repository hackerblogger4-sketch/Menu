from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://qruser:qrpassword@localhost:5432/qrrestaurant"
    jwt_secret: str = "CHANGE_ME_TO_A_LONG_RANDOM_SECRET_32_CHARS_MINIMUM"
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 60
    model_config = SettingsConfigDict(env_file=".env", case_sensitive=False, extra="ignore")

settings = Settings()
