from pydantic import BaseModel, Field
from typing import Optional

class CategoryOut(BaseModel):
    id: str
    name: str
    sort_order: int

class MenuItemOut(BaseModel):
    id: str
    category_id: Optional[str]
    name: str
    description: Optional[str]
    price: int
    currency: str
    image_url: Optional[str]
    available: bool
    sort_order: int

class PublicMenuOut(BaseModel):
    restaurant_id: str
    restaurant_name: str
    slug: str
    table_id: str
    table_number: str
    categories: list[CategoryOut]
    items: list[MenuItemOut]

class QRResponse(BaseModel):
    restaurant_id: str
    table_id: str
    table_number: str
    qr_url: str
    token: str
