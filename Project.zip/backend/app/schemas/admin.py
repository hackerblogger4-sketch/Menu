from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict
from app.models import UserRole

class CategoryCreate(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    sort_order: int = 0
class CategoryUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=150)
    sort_order: int | None = None
class CategoryAdminOut(CategoryCreate):
    id: str
    model_config = ConfigDict(from_attributes=True)

class MenuItemCreate(BaseModel):
    category_id: str | None = None
    name: str = Field(min_length=1, max_length=200)
    description: str | None = None
    price: int = Field(ge=0)
    currency: str = Field(default="KRW", min_length=3, max_length=3)
    image_url: str | None = None
    available: bool = True
    sort_order: int = 0
class MenuItemUpdate(BaseModel):
    category_id: str | None = None
    name: str | None = Field(default=None, min_length=1, max_length=200)
    description: str | None = None
    price: int | None = Field(default=None, ge=0)
    currency: str | None = Field(default=None, min_length=3, max_length=3)
    image_url: str | None = None
    available: bool | None = None
    sort_order: int | None = None
class MenuItemAdminOut(MenuItemCreate):
    id: str
    model_config = ConfigDict(from_attributes=True)

class TableCreate(BaseModel):
    table_number: str = Field(min_length=1, max_length=50)
    active: bool = True
class TableUpdate(BaseModel):
    table_number: str | None = Field(default=None, min_length=1, max_length=50)
    active: bool | None = None
class TableAdminOut(BaseModel):
    id: str
    table_number: str
    qr_token: str
    active: bool
    qr_url: str

class StaffCreate(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    email: str
    password: str = Field(min_length=8, max_length=128)
    role: UserRole
class StaffUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=150)
    active: bool | None = None
    role: UserRole | None = None
class StaffOut(BaseModel):
    id: str; name: str; email: str; role: UserRole; active: bool
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)

class RestaurantSettingsUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    slug: str | None = Field(default=None, min_length=1, max_length=120)
    phone: str | None = None
    address: str | None = None
    logo_url: str | None = None
    currency: str | None = Field(default=None, min_length=3, max_length=3)
    default_language: str | None = Field(default=None, min_length=2, max_length=10)
class RestaurantSettingsOut(BaseModel):
    id: str; name: str; slug: str; phone: str | None; address: str | None; logo_url: str | None; currency: str; default_language: str

class RestaurantAdminStats(BaseModel):
    categories: int; menu_items: int; active_menu_items: int; tables: int; active_tables: int; staff: int
