from pydantic import BaseModel, EmailStr, ConfigDict
from app.models import UserRole
class LoginRequest(BaseModel):
    email: EmailStr
    password: str
class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str; name: str; email: EmailStr; role: UserRole; restaurant_id: str | None
