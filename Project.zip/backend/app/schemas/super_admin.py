from datetime import datetime
from pydantic import BaseModel, Field

class PlatformSettingsUpdate(BaseModel):
    platform_name: str | None = Field(default=None, max_length=120)
    maintenance_mode: bool | None = None
    default_currency: str | None = Field(default=None, min_length=3, max_length=3)
    allow_new_restaurants: bool | None = None
class PlatformSettingsOut(BaseModel):
    platform_name: str; maintenance_mode: bool; default_currency: str; allow_new_restaurants: bool

class PlatformStats(BaseModel):
    restaurants_total: int; restaurants_active: int; restaurants_blocked: int; restaurants_deleted: int
    users_total: int; orders_total: int; menu_items_total: int

class AuditOut(BaseModel):
    id: int; actor_user_id: str | None; restaurant_id: str | None; action: str; reason: str | None; metadata: dict | None; created_at: datetime


class RestaurantCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    slug: str = Field(min_length=1, max_length=120)
    currency: str = Field(default="KRW", min_length=3, max_length=3)
    default_language: str = Field(default="ko", min_length=2, max_length=10)

class RestaurantUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    slug: str | None = Field(default=None, min_length=1, max_length=120)
    currency: str | None = Field(default=None, min_length=3, max_length=3)
    default_language: str | None = Field(default=None, min_length=2, max_length=10)
