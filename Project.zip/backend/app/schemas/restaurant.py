from datetime import datetime
from pydantic import BaseModel
from app.models import RestaurantStatus
class StatusUpdate(BaseModel):
    status: RestaurantStatus
    reason: str | None = None
    blocked_until: datetime | None = None
class RestaurantResponse(BaseModel):
    id: str; name: str; slug: str; status: RestaurantStatus; block_reason: str | None; blocked_until: datetime | None
    class Config: from_attributes = True
