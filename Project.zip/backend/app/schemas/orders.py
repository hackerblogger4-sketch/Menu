from pydantic import BaseModel, Field
from typing import Optional

class OrderItemIn(BaseModel):
    menu_item_id: str
    quantity: int = Field(ge=1, le=99)

class CreateOrderIn(BaseModel):
    items: list[OrderItemIn] = Field(min_length=1, max_length=100)
    note: Optional[str] = Field(default=None, max_length=1000)
    idempotency_key: Optional[str] = Field(default=None, min_length=8, max_length=128)

class OrderItemOut(BaseModel):
    menu_item_id: str
    name: str
    quantity: int
    unit_price: int
    subtotal: int

class OrderOut(BaseModel):
    id: str
    order_number: int
    restaurant_id: str
    table_id: str
    table_number: str
    status: str
    total: int
    currency: str
    note: Optional[str]
    items: list[OrderItemOut]
    created_at: str
    updated_at: str

class StatusUpdateIn(BaseModel):
    status: str
