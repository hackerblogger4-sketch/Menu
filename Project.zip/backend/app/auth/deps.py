from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session
from app.auth.security import decode_token
from app.db.session import get_db
from app.models import User, UserRole, RestaurantStatus

bearer = HTTPBearer(auto_error=False)

def current_user(creds: HTTPAuthorizationCredentials = Depends(bearer), db: Session = Depends(get_db)) -> User:
    if not creds: raise HTTPException(status_code=401, detail="Authentication required")
    try: payload = decode_token(creds.credentials); user_id = payload.get("sub")
    except Exception: raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = db.get(User, user_id)
    if not user or not user.active: raise HTTPException(status_code=401, detail="Inactive user")
    if user.role != UserRole.SUPER_ADMIN and user.restaurant:
        if user.restaurant.status in (RestaurantStatus.BLOCKED, RestaurantStatus.DELETED):
            raise HTTPException(status_code=403, detail="RESTAURANT_BLOCKED")
    return user

def require_role(*roles: UserRole):
    def dep(user: User = Depends(current_user)):
        if user.role not in roles: raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user
    return dep
