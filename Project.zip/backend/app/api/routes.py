import io
import secrets
import qrcode
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.auth.deps import current_user, require_role
from app.auth.security import create_access_token, verify_password
from app.db.session import get_db
from app.models import User, UserRole, Restaurant, RestaurantStatus, AuditLog, RestaurantTable, Category, MenuItem
from app.schemas.auth import LoginRequest, TokenResponse, UserResponse
from app.schemas.restaurant import StatusUpdate, RestaurantResponse
from app.schemas.menu import PublicMenuOut, CategoryOut, MenuItemOut, QRResponse

router = APIRouter(prefix="/api/v1")

def ensure_restaurant_available(r: Restaurant):
    if r.status in (RestaurantStatus.BLOCKED, RestaurantStatus.DELETED):
        raise HTTPException(status_code=403, detail="RESTAURANT_BLOCKED")

@router.get("/health")
def health():
    return {"ok": True, "service": "qr-restaurant-platform", "stage": 5}

@router.post("/auth/login", response_model=TokenResponse)
def login(data: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == data.email.lower()))
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if not user.active:
        raise HTTPException(status_code=403, detail="User inactive")
    if user.role != UserRole.SUPER_ADMIN and user.restaurant:
        ensure_restaurant_available(user.restaurant)
    return TokenResponse(access_token=create_access_token(user.id))

@router.get("/auth/me", response_model=UserResponse)
def me(user: User = Depends(current_user)):
    return user

@router.get("/super/restaurants", response_model=list[RestaurantResponse])
def restaurants(db: Session = Depends(get_db), _: User = Depends(require_role(UserRole.SUPER_ADMIN))):
    return db.scalars(select(Restaurant).order_by(Restaurant.created_at.desc())).all()

@router.patch("/super/restaurants/{restaurant_id}/status", response_model=RestaurantResponse)
def update_status(restaurant_id: str, data: StatusUpdate, db: Session = Depends(get_db), admin: User = Depends(require_role(UserRole.SUPER_ADMIN))):
    r = db.get(Restaurant, restaurant_id)
    if not r:
        raise HTTPException(status_code=404, detail="Restaurant not found")
    old = r.status
    r.status = data.status
    r.block_reason = data.reason if data.status == RestaurantStatus.BLOCKED else None
    r.blocked_until = data.blocked_until if data.status == RestaurantStatus.BLOCKED else None
    db.add(AuditLog(
        actor_user_id=admin.id, restaurant_id=r.id,
        action="RESTAURANT_STATUS_CHANGED", reason=data.reason,
        metadata_json={"previous_status": old.value if hasattr(old, "value") else str(old), "new_status": data.status.value}
    ))
    db.commit(); db.refresh(r)
    return r

@router.get("/public/tables/{token}/menu", response_model=PublicMenuOut)
def public_menu(token: str, db: Session = Depends(get_db)):
    table = db.scalar(select(RestaurantTable).where(RestaurantTable.qr_token == token, RestaurantTable.active.is_(True)))
    if not table:
        raise HTTPException(status_code=404, detail="QR_TABLE_NOT_FOUND")
    restaurant = db.get(Restaurant, table.restaurant_id)
    if not restaurant:
        raise HTTPException(status_code=404, detail="RESTAURANT_NOT_FOUND")
    ensure_restaurant_available(restaurant)

    categories = db.scalars(
        select(Category).where(Category.restaurant_id == restaurant.id).order_by(Category.sort_order, Category.name)
    ).all()
    items = db.scalars(
        select(MenuItem).where(MenuItem.restaurant_id == restaurant.id, MenuItem.available.is_(True))
        .order_by(MenuItem.sort_order, MenuItem.name)
    ).all()

    return PublicMenuOut(
        restaurant_id=restaurant.id,
        restaurant_name=restaurant.name,
        slug=restaurant.slug,
        table_id=table.id,
        table_number=table.table_number,
        categories=[CategoryOut(id=c.id, name=c.name, sort_order=c.sort_order) for c in categories],
        items=[MenuItemOut(
            id=i.id, category_id=i.category_id, name=i.name, description=i.description,
            price=i.price, currency=i.currency, image_url=i.image_url,
            available=i.available, sort_order=i.sort_order
        ) for i in items]
    )

@router.post("/restaurant/tables/{table_id}/qr", response_model=QRResponse)
def regenerate_qr(
    table_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(require_role(UserRole.RESTAURANT_OWNER, UserRole.RESTAURANT_ADMIN))
):
    table = db.get(RestaurantTable, table_id)
    if not table or table.restaurant_id != user.restaurant_id:
        raise HTTPException(status_code=404, detail="Table not found")
    restaurant = db.get(Restaurant, user.restaurant_id)
    ensure_restaurant_available(restaurant)
    table.qr_token = secrets.token_urlsafe(32)
    db.add(AuditLog(
        actor_user_id=user.id, restaurant_id=restaurant.id,
        action="TABLE_QR_REGENERATED",
        metadata_json={"table_id": table.id, "table_number": table.table_number}
    ))
    db.commit()
    return QRResponse(
        restaurant_id=restaurant.id, table_id=table.id,
        table_number=table.table_number, token=table.qr_token,
        qr_url=f"/api/v1/public/tables/{table.qr_token}/menu"
    )

@router.get("/public/tables/{token}/qr.png")
def qr_png(token: str, db: Session = Depends(get_db)):
    table = db.scalar(select(RestaurantTable).where(RestaurantTable.qr_token == token, RestaurantTable.active.is_(True)))
    if not table:
        raise HTTPException(status_code=404, detail="QR_TABLE_NOT_FOUND")
    restaurant = db.get(Restaurant, table.restaurant_id)
    if not restaurant:
        raise HTTPException(status_code=404, detail="RESTAURANT_NOT_FOUND")
    ensure_restaurant_available(restaurant)

    img = qrcode.make(f"/api/v1/public/tables/{token}/menu")
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    buffer.seek(0)
    return StreamingResponse(buffer, media_type="image/png")

# ---- Stage 3: Orders + real-time Order Panel ----
from fastapi import WebSocket, WebSocketDisconnect
from sqlalchemy import func
from app.models import Order, OrderItem
from app.schemas.orders import CreateOrderIn, OrderOut, OrderItemOut, StatusUpdateIn

ORDER_STATUSES = {"new", "accepted", "preparing", "ready", "delivered", "completed", "cancelled"}

class RestaurantSocketManager:
    def __init__(self):
        self.connections: dict[str, set[WebSocket]] = {}

    async def connect(self, restaurant_id: str, websocket: WebSocket):
        await websocket.accept()
        self.connections.setdefault(restaurant_id, set()).add(websocket)

    def disconnect(self, restaurant_id: str, websocket: WebSocket):
        self.connections.get(restaurant_id, set()).discard(websocket)

    async def broadcast(self, restaurant_id: str, payload: dict):
        dead = []
        for ws in list(self.connections.get(restaurant_id, set())):
            try:
                await ws.send_json(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(restaurant_id, ws)

socket_manager = RestaurantSocketManager()


def serialize_order(order: Order, table: RestaurantTable, items: list[OrderItem]) -> OrderOut:
    return OrderOut(
        id=order.id, order_number=order.order_number, restaurant_id=order.restaurant_id,
        table_id=order.table_id, table_number=table.table_number, status=order.status,
        total=order.total, currency=order.currency, note=order.note,
        items=[OrderItemOut(menu_item_id=i.menu_item_id, name=i.name_snapshot, quantity=i.quantity,
                            unit_price=i.unit_price, subtotal=i.subtotal) for i in items],
        created_at=order.created_at.isoformat(), updated_at=order.updated_at.isoformat()
    )


def get_order_or_404(db: Session, order_id: str, user: User):
    order = db.get(Order, order_id)
    if not order or order.restaurant_id != user.restaurant_id:
        raise HTTPException(status_code=404, detail="ORDER_NOT_FOUND")
    ensure_restaurant_available(db.get(Restaurant, order.restaurant_id))
    return order

@router.post("/public/tables/{token}/orders", response_model=OrderOut, status_code=201)
def create_public_order(token: str, data: CreateOrderIn, db: Session = Depends(get_db)):
    table = db.scalar(select(RestaurantTable).where(RestaurantTable.qr_token == token, RestaurantTable.active.is_(True)))
    if not table:
        raise HTTPException(status_code=404, detail="QR_TABLE_NOT_FOUND")
    restaurant = db.get(Restaurant, table.restaurant_id)
    if not restaurant:
        raise HTTPException(status_code=404, detail="RESTAURANT_NOT_FOUND")
    ensure_restaurant_available(restaurant)

    if data.idempotency_key:
        existing = db.scalar(select(Order).where(Order.restaurant_id == restaurant.id, Order.idempotency_key == data.idempotency_key))
        if existing:
            existing_items = db.scalars(select(OrderItem).where(OrderItem.order_id == existing.id)).all()
            return serialize_order(existing, table, existing_items)

    ids = [x.menu_item_id for x in data.items]
    if len(set(ids)) != len(ids):
        raise HTTPException(status_code=422, detail="DUPLICATE_MENU_ITEM")
    menu_items = db.scalars(select(MenuItem).where(MenuItem.restaurant_id == restaurant.id, MenuItem.id.in_(ids))).all()
    by_id = {x.id: x for x in menu_items}
    if len(by_id) != len(ids):
        raise HTTPException(status_code=400, detail="MENU_ITEM_NOT_FOUND_OR_WRONG_RESTAURANT")

    total = 0
    order_items = []
    currency = None
    for requested in data.items:
        item = by_id[requested.menu_item_id]
        if not item.available:
            raise HTTPException(status_code=409, detail=f"MENU_ITEM_UNAVAILABLE:{item.id}")
        if currency is None: currency = item.currency
        if currency != item.currency:
            raise HTTPException(status_code=400, detail="MIXED_CURRENCY_NOT_ALLOWED")
        subtotal = item.price * requested.quantity
        total += subtotal
        order_items.append((item, requested.quantity, subtotal))

    last_number = db.scalar(select(func.max(Order.order_number)).where(Order.restaurant_id == restaurant.id)) or 0
    order = Order(restaurant_id=restaurant.id, table_id=table.id, order_number=last_number + 1,
                  status="new", total=total, currency=currency or "KRW", note=data.note,
                  idempotency_key=data.idempotency_key)
    db.add(order); db.flush()
    for item, qty, subtotal in order_items:
        db.add(OrderItem(order_id=order.id, menu_item_id=item.id, name_snapshot=item.name,
                          unit_price=item.price, quantity=qty, subtotal=subtotal))
    db.add(AuditLog(restaurant_id=restaurant.id, action="ORDER_CREATED",
                    metadata_json={"order_id": order.id, "order_number": order.order_number, "table_id": table.id}))
    _notify_staff(db, restaurant.id, "NEW_ORDER", f"Yangi buyurtma #{order.order_number}", f"Stol {table.table_number} dan yangi buyurtma keldi.", {"order_id": order.id, "order_number": order.order_number, "table_id": table.id})
    db.commit(); db.refresh(order)
    saved_items = db.scalars(select(OrderItem).where(OrderItem.order_id == order.id)).all()
    return serialize_order(order, table, saved_items)

@router.get("/restaurant/orders", response_model=list[OrderOut])
def list_orders(status: str | None = None, limit: int = 100, db: Session = Depends(get_db),
                user: User = Depends(require_role(UserRole.RESTAURANT_OWNER, UserRole.RESTAURANT_ADMIN, UserRole.ORDER_OPERATOR, UserRole.KITCHEN))):
    if not user.restaurant_id: raise HTTPException(status_code=403, detail="RESTAURANT_REQUIRED")
    ensure_restaurant_available(db.get(Restaurant, user.restaurant_id))
    if status and status not in ORDER_STATUSES: raise HTTPException(status_code=400, detail="INVALID_STATUS")
    stmt = select(Order).where(Order.restaurant_id == user.restaurant_id).order_by(Order.created_at.desc()).limit(min(max(limit, 1), 200))
    if status: stmt = stmt.where(Order.status == status)
    orders = db.scalars(stmt).all()
    out=[]
    for order in orders:
        table=db.get(RestaurantTable, order.table_id)
        items=db.scalars(select(OrderItem).where(OrderItem.order_id == order.id)).all()
        out.append(serialize_order(order, table, items))
    return out

@router.patch("/restaurant/orders/{order_id}/status", response_model=OrderOut)
async def update_order_status(order_id: str, data: StatusUpdateIn, db: Session = Depends(get_db),
                              user: User = Depends(require_role(UserRole.RESTAURANT_OWNER, UserRole.RESTAURANT_ADMIN, UserRole.ORDER_OPERATOR, UserRole.KITCHEN))):
    if data.status not in ORDER_STATUSES: raise HTTPException(status_code=400, detail="INVALID_STATUS")
    order = get_order_or_404(db, order_id, user)
    old = order.status
    order.status = data.status
    db.add(AuditLog(actor_user_id=user.id, restaurant_id=user.restaurant_id, action="ORDER_STATUS_CHANGED",
                    metadata_json={"order_id": order.id, "order_number": order.order_number, "previous_status": old, "new_status": data.status}))
    db.commit(); db.refresh(order)
    table=db.get(RestaurantTable, order.table_id); items=db.scalars(select(OrderItem).where(OrderItem.order_id == order.id)).all()
    payload=serialize_order(order, table, items).model_dump()
    await socket_manager.broadcast(user.restaurant_id, {"event":"order.updated", "order":payload})
    return serialize_order(order, table, items)

@router.websocket("/restaurant/orders/ws")
async def order_websocket(websocket: WebSocket, token: str):
    # Token is passed as a query parameter so browser/native WebSocket clients can connect without custom headers.
    from app.auth.security import decode_token
    try:
        payload = decode_token(token); user_id = payload.get("sub")
    except Exception:
        await websocket.close(code=1008); return
    db = next(get_db())
    try:
        user = db.get(User, user_id)
        if not user or not user.active or user.role == UserRole.SUPER_ADMIN or not user.restaurant_id:
            await websocket.close(code=1008); return
        restaurant = db.get(Restaurant, user.restaurant_id)
        if not restaurant or restaurant.status in (RestaurantStatus.BLOCKED, RestaurantStatus.DELETED):
            await websocket.close(code=1008); return
        await socket_manager.connect(user.restaurant_id, websocket)
        await websocket.send_json({"event":"connected", "restaurant_id":user.restaurant_id})
        while True:
            message = await websocket.receive_text()
            if message == "ping": await websocket.send_json({"event":"pong"})
    except WebSocketDisconnect:
        pass
    finally:
        socket_manager.disconnect(getattr(locals().get("user", None), "restaurant_id", ""), websocket)
        db.close()

# ---- Stage 4: Restaurant Admin CRUD ----
from app.schemas.admin import (
    CategoryCreate, CategoryUpdate, CategoryAdminOut, MenuItemCreate, MenuItemUpdate, MenuItemAdminOut,
    TableCreate, TableUpdate, TableAdminOut, StaffCreate, StaffUpdate, StaffOut,
    RestaurantSettingsUpdate, RestaurantSettingsOut, RestaurantAdminStats,
)
from app.auth.security import hash_password

ADMIN_ROLES = (UserRole.RESTAURANT_OWNER, UserRole.RESTAURANT_ADMIN)
STAFF_ROLES = (UserRole.RESTAURANT_ADMIN, UserRole.ORDER_OPERATOR, UserRole.KITCHEN)

def restaurant_admin(user: User):
    if not user.restaurant_id:
        raise HTTPException(status_code=403, detail="RESTAURANT_REQUIRED")
    return user

def ensure_category(db: Session, user: User, category_id: str | None):
    if category_id is None: return None
    c = db.get(Category, category_id)
    if not c or c.restaurant_id != user.restaurant_id:
        raise HTTPException(status_code=400, detail="CATEGORY_NOT_FOUND_OR_WRONG_RESTAURANT")
    return c

def unique_table_check(db: Session, restaurant_id: str, table_number: str, exclude_id: str | None = None):
    stmt = select(RestaurantTable).where(RestaurantTable.restaurant_id == restaurant_id, RestaurantTable.table_number == table_number)
    if exclude_id: stmt = stmt.where(RestaurantTable.id != exclude_id)
    if db.scalar(stmt): raise HTTPException(status_code=409, detail="TABLE_NUMBER_ALREADY_EXISTS")

@router.get("/restaurant/admin/stats", response_model=RestaurantAdminStats)
def restaurant_stats(db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    restaurant_admin(user); ensure_restaurant_available(db.get(Restaurant, user.restaurant_id))
    cats = db.scalar(select(func.count()).select_from(Category).where(Category.restaurant_id == user.restaurant_id)) or 0
    items = db.scalar(select(func.count()).select_from(MenuItem).where(MenuItem.restaurant_id == user.restaurant_id)) or 0
    active_items = db.scalar(select(func.count()).select_from(MenuItem).where(MenuItem.restaurant_id == user.restaurant_id, MenuItem.available.is_(True))) or 0
    tables = db.scalar(select(func.count()).select_from(RestaurantTable).where(RestaurantTable.restaurant_id == user.restaurant_id)) or 0
    active_tables = db.scalar(select(func.count()).select_from(RestaurantTable).where(RestaurantTable.restaurant_id == user.restaurant_id, RestaurantTable.active.is_(True))) or 0
    staff = db.scalar(select(func.count()).select_from(User).where(User.restaurant_id == user.restaurant_id)) or 0
    return RestaurantAdminStats(categories=cats, menu_items=items, active_menu_items=active_items, tables=tables, active_tables=active_tables, staff=staff)

@router.get("/restaurant/admin/settings", response_model=RestaurantSettingsOut)
def get_restaurant_settings(db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    r = db.get(Restaurant, restaurant_admin(user).restaurant_id); ensure_restaurant_available(r)
    return RestaurantSettingsOut(id=r.id, name=r.name, slug=r.slug, phone=r.phone, address=r.address, logo_url=r.logo_url, currency=r.currency, default_language=r.default_language)

@router.patch("/restaurant/admin/settings", response_model=RestaurantSettingsOut)
def update_restaurant_settings(data: RestaurantSettingsUpdate, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    r = db.get(Restaurant, restaurant_admin(user).restaurant_id); ensure_restaurant_available(r)
    if data.slug and data.slug != r.slug and db.scalar(select(Restaurant).where(Restaurant.slug == data.slug)):
        raise HTTPException(status_code=409, detail="SLUG_ALREADY_EXISTS")
    for field in ("name", "slug", "phone", "address", "logo_url", "currency", "default_language"):
        value = getattr(data, field)
        if value is not None: setattr(r, field, value)
    db.add(AuditLog(actor_user_id=user.id, restaurant_id=r.id, action="RESTAURANT_SETTINGS_UPDATED"))
    db.commit(); db.refresh(r)
    return RestaurantSettingsOut(id=r.id, name=r.name, slug=r.slug, phone=r.phone, address=r.address, logo_url=r.logo_url, currency=r.currency, default_language=r.default_language)

@router.get("/restaurant/admin/categories", response_model=list[CategoryAdminOut])
def list_categories(db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    restaurant_admin(user); return db.scalars(select(Category).where(Category.restaurant_id == user.restaurant_id).order_by(Category.sort_order, Category.name)).all()

@router.post("/restaurant/admin/categories", response_model=CategoryAdminOut, status_code=201)
def create_category(data: CategoryCreate, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    restaurant_admin(user); ensure_restaurant_available(db.get(Restaurant, user.restaurant_id))
    c = Category(restaurant_id=user.restaurant_id, name=data.name, sort_order=data.sort_order); db.add(c)
    db.add(AuditLog(actor_user_id=user.id, restaurant_id=user.restaurant_id, action="CATEGORY_CREATED", metadata_json={"name":data.name}))
    db.commit(); db.refresh(c); return c

@router.patch("/restaurant/admin/categories/{category_id}", response_model=CategoryAdminOut)
def update_category(category_id: str, data: CategoryUpdate, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    c=db.get(Category, category_id)
    if not c or c.restaurant_id != restaurant_admin(user).restaurant_id: raise HTTPException(status_code=404, detail="CATEGORY_NOT_FOUND")
    for f in ("name","sort_order"):
        v=getattr(data,f)
        if v is not None: setattr(c,f,v)
    db.add(AuditLog(actor_user_id=user.id, restaurant_id=user.restaurant_id, action="CATEGORY_UPDATED", metadata_json={"category_id":c.id})); db.commit(); db.refresh(c); return c

@router.delete("/restaurant/admin/categories/{category_id}", status_code=204)
def delete_category(category_id: str, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    c=db.get(Category, category_id)
    if not c or c.restaurant_id != restaurant_admin(user).restaurant_id: raise HTTPException(status_code=404, detail="CATEGORY_NOT_FOUND")
    db.delete(c); db.add(AuditLog(actor_user_id=user.id, restaurant_id=user.restaurant_id, action="CATEGORY_DELETED", metadata_json={"category_id":category_id})); db.commit()

@router.get("/restaurant/admin/menu-items", response_model=list[MenuItemAdminOut])
def list_menu_items(db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    restaurant_admin(user); return db.scalars(select(MenuItem).where(MenuItem.restaurant_id == user.restaurant_id).order_by(MenuItem.sort_order, MenuItem.name)).all()

@router.post("/restaurant/admin/menu-items", response_model=MenuItemAdminOut, status_code=201)
def create_menu_item(data: MenuItemCreate, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    restaurant_admin(user); ensure_restaurant_available(db.get(Restaurant, user.restaurant_id)); ensure_category(db,user,data.category_id)
    currency=data.currency.upper(); item=MenuItem(restaurant_id=user.restaurant_id, category_id=data.category_id, name=data.name, description=data.description, price=data.price, currency=currency, image_url=data.image_url, available=data.available, sort_order=data.sort_order)
    db.add(item); db.add(AuditLog(actor_user_id=user.id, restaurant_id=user.restaurant_id, action="MENU_ITEM_CREATED", metadata_json={"name":data.name})); db.commit(); db.refresh(item); return item

@router.patch("/restaurant/admin/menu-items/{item_id}", response_model=MenuItemAdminOut)
def update_menu_item(item_id: str, data: MenuItemUpdate, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    item=db.get(MenuItem,item_id)
    if not item or item.restaurant_id != restaurant_admin(user).restaurant_id: raise HTTPException(status_code=404, detail="MENU_ITEM_NOT_FOUND")
    if data.category_id is not None: ensure_category(db,user,data.category_id)
    for f in ("category_id","name","description","price","image_url","available","sort_order"):
        v=getattr(data,f)
        if v is not None: setattr(item,f,v)
    if data.currency is not None: item.currency=data.currency.upper()
    db.add(AuditLog(actor_user_id=user.id, restaurant_id=user.restaurant_id, action="MENU_ITEM_UPDATED", metadata_json={"item_id":item.id})); db.commit(); db.refresh(item); return item

@router.delete("/restaurant/admin/menu-items/{item_id}", status_code=204)
def delete_menu_item(item_id: str, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    item=db.get(MenuItem,item_id)
    if not item or item.restaurant_id != restaurant_admin(user).restaurant_id: raise HTTPException(status_code=404, detail="MENU_ITEM_NOT_FOUND")
    db.delete(item); db.add(AuditLog(actor_user_id=user.id, restaurant_id=user.restaurant_id, action="MENU_ITEM_DELETED", metadata_json={"item_id":item_id})); db.commit()

@router.get("/restaurant/admin/tables", response_model=list[TableAdminOut])
def list_tables(db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    restaurant_admin(user); rows=db.scalars(select(RestaurantTable).where(RestaurantTable.restaurant_id==user.restaurant_id).order_by(RestaurantTable.table_number)).all()
    return [TableAdminOut(id=t.id, table_number=t.table_number, qr_token=t.qr_token, active=t.active, qr_url=f"/api/v1/public/tables/{t.qr_token}/menu") for t in rows]

@router.post("/restaurant/admin/tables", response_model=TableAdminOut, status_code=201)
def create_table(data: TableCreate, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    restaurant_admin(user); ensure_restaurant_available(db.get(Restaurant,user.restaurant_id)); unique_table_check(db,user.restaurant_id,data.table_number)
    t=RestaurantTable(restaurant_id=user.restaurant_id, table_number=data.table_number, qr_token=secrets.token_urlsafe(32), active=data.active); db.add(t); db.flush()
    db.add(AuditLog(actor_user_id=user.id, restaurant_id=user.restaurant_id, action="TABLE_CREATED", metadata_json={"table_id":t.id,"table_number":t.table_number})); db.commit(); db.refresh(t)
    return TableAdminOut(id=t.id,table_number=t.table_number,qr_token=t.qr_token,active=t.active,qr_url=f"/api/v1/public/tables/{t.qr_token}/menu")

@router.patch("/restaurant/admin/tables/{table_id}", response_model=TableAdminOut)
def update_table(table_id: str, data: TableUpdate, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    t=db.get(RestaurantTable,table_id)
    if not t or t.restaurant_id != restaurant_admin(user).restaurant_id: raise HTTPException(status_code=404,detail="TABLE_NOT_FOUND")
    if data.table_number is not None and data.table_number != t.table_number: unique_table_check(db,user.restaurant_id,data.table_number,t.id); t.table_number=data.table_number
    if data.active is not None: t.active=data.active
    db.add(AuditLog(actor_user_id=user.id,restaurant_id=user.restaurant_id,action="TABLE_UPDATED",metadata_json={"table_id":t.id})); db.commit(); db.refresh(t)
    return TableAdminOut(id=t.id,table_number=t.table_number,qr_token=t.qr_token,active=t.active,qr_url=f"/api/v1/public/tables/{t.qr_token}/menu")

@router.delete("/restaurant/admin/tables/{table_id}", status_code=204)
def delete_table(table_id: str, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    t=db.get(RestaurantTable,table_id)
    if not t or t.restaurant_id != restaurant_admin(user).restaurant_id: raise HTTPException(status_code=404,detail="TABLE_NOT_FOUND")
    t.active=False; db.add(AuditLog(actor_user_id=user.id,restaurant_id=user.restaurant_id,action="TABLE_DEACTIVATED",metadata_json={"table_id":t.id})); db.commit()

@router.get("/restaurant/admin/staff", response_model=list[StaffOut])
def list_staff(db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    restaurant_admin(user); return db.scalars(select(User).where(User.restaurant_id==user.restaurant_id).order_by(User.created_at.desc())).all()

@router.post("/restaurant/admin/staff", response_model=StaffOut, status_code=201)
def create_staff(data: StaffCreate, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    restaurant_admin(user); ensure_restaurant_available(db.get(Restaurant,user.restaurant_id))
    if data.role not in STAFF_ROLES: raise HTTPException(status_code=400,detail="ROLE_NOT_ALLOWED")
    email=data.email.lower()
    if db.scalar(select(User).where(User.email==email)): raise HTTPException(status_code=409,detail="EMAIL_ALREADY_EXISTS")
    u=User(restaurant_id=user.restaurant_id,name=data.name,email=email,password_hash=hash_password(data.password),role=data.role,active=True); db.add(u); db.flush()
    db.add(AuditLog(actor_user_id=user.id,restaurant_id=user.restaurant_id,action="STAFF_CREATED",metadata_json={"user_id":u.id,"role":u.role.value})); db.commit(); db.refresh(u); return u

@router.patch("/restaurant/admin/staff/{staff_id}", response_model=StaffOut)
def update_staff(staff_id: str, data: StaffUpdate, db: Session = Depends(get_db), user: User = Depends(require_role(*ADMIN_ROLES))):
    u=db.get(User,staff_id)
    if not u or u.restaurant_id != restaurant_admin(user).restaurant_id: raise HTTPException(status_code=404,detail="STAFF_NOT_FOUND")
    if u.id == user.id and data.active is False: raise HTTPException(status_code=400,detail="CANNOT_DEACTIVATE_SELF")
    if data.role is not None and data.role not in STAFF_ROLES: raise HTTPException(status_code=400,detail="ROLE_NOT_ALLOWED")
    for f in ("name","active","role"):
        v=getattr(data,f)
        if v is not None: setattr(u,f,v)
    db.add(AuditLog(actor_user_id=user.id,restaurant_id=user.restaurant_id,action="STAFF_UPDATED",metadata_json={"user_id":u.id})); db.commit(); db.refresh(u); return u

# ---- Stage 5: Super Admin / Developer panel ----
from sqlalchemy import or_, desc
from app.models import PlatformSetting
from app.schemas.super_admin import PlatformSettingsUpdate, PlatformSettingsOut, PlatformStats, AuditOut, RestaurantCreate, RestaurantUpdate

@router.get("/super/stats", response_model=PlatformStats)
def super_stats(db: Session = Depends(get_db), _: User = Depends(require_role(UserRole.SUPER_ADMIN))):
    total=db.scalar(select(func.count()).select_from(Restaurant)) or 0
    active=db.scalar(select(func.count()).select_from(Restaurant).where(Restaurant.status==RestaurantStatus.ACTIVE)) or 0
    blocked=db.scalar(select(func.count()).select_from(Restaurant).where(Restaurant.status==RestaurantStatus.BLOCKED)) or 0
    deleted=db.scalar(select(func.count()).select_from(Restaurant).where(Restaurant.status==RestaurantStatus.DELETED)) or 0
    users=db.scalar(select(func.count()).select_from(User)) or 0
    orders=db.scalar(select(func.count()).select_from(Order)) or 0
    items=db.scalar(select(func.count()).select_from(MenuItem)) or 0
    return PlatformStats(restaurants_total=total,restaurants_active=active,restaurants_blocked=blocked,restaurants_deleted=deleted,users_total=users,orders_total=orders,menu_items_total=items)

@router.post("/super/restaurants", response_model=RestaurantResponse, status_code=201)
def super_create_restaurant(data: RestaurantCreate, db: Session = Depends(get_db), admin: User = Depends(require_role(UserRole.SUPER_ADMIN))):
    settings=get_platform_settings(db)
    if not settings.allow_new_restaurants: raise HTTPException(status_code=403, detail="NEW_RESTAURANTS_DISABLED")
    if db.scalar(select(Restaurant).where(Restaurant.slug==data.slug)): raise HTTPException(status_code=409, detail="SLUG_ALREADY_EXISTS")
    r=Restaurant(name=data.name,slug=data.slug,currency=data.currency.upper(),default_language=data.default_language)
    db.add(r); db.flush(); db.add(AuditLog(actor_user_id=admin.id,restaurant_id=r.id,action="RESTAURANT_CREATED",metadata_json={"slug":r.slug})); db.commit(); db.refresh(r); return r

@router.patch("/super/restaurants/{restaurant_id}", response_model=RestaurantResponse)
def super_update_restaurant(restaurant_id: str, data: RestaurantUpdate, db: Session = Depends(get_db), admin: User = Depends(require_role(UserRole.SUPER_ADMIN))):
    r=db.get(Restaurant,restaurant_id)
    if not r: raise HTTPException(status_code=404,detail="Restaurant not found")
    if data.slug and data.slug != r.slug and db.scalar(select(Restaurant).where(Restaurant.slug==data.slug)): raise HTTPException(status_code=409,detail="SLUG_ALREADY_EXISTS")
    for f in ("name","slug","default_language"):
        v=getattr(data,f)
        if v is not None: setattr(r,f,v)
    if data.currency is not None: r.currency=data.currency.upper()
    db.add(AuditLog(actor_user_id=admin.id,restaurant_id=r.id,action="RESTAURANT_UPDATED",metadata_json={"restaurant_id":r.id})); db.commit(); db.refresh(r); return r

@router.get("/super/restaurants/{restaurant_id}", response_model=RestaurantResponse)
def super_restaurant_detail(restaurant_id: str, db: Session = Depends(get_db), _: User = Depends(require_role(UserRole.SUPER_ADMIN))):
    r=db.get(Restaurant,restaurant_id)
    if not r: raise HTTPException(status_code=404,detail="Restaurant not found")
    return r

@router.get("/super/restaurants/{restaurant_id}/users", response_model=list[StaffOut])
def super_restaurant_users(restaurant_id: str, db: Session = Depends(get_db), _: User = Depends(require_role(UserRole.SUPER_ADMIN))):
    if not db.get(Restaurant,restaurant_id): raise HTTPException(status_code=404,detail="Restaurant not found")
    return db.scalars(select(User).where(User.restaurant_id==restaurant_id).order_by(User.created_at.desc())).all()

@router.get("/super/audit-logs", response_model=list[AuditOut])
def super_audit_logs(restaurant_id: str | None = None, limit: int = 100, db: Session = Depends(get_db), _: User = Depends(require_role(UserRole.SUPER_ADMIN))):
    stmt=select(AuditLog).order_by(desc(AuditLog.created_at)).limit(min(max(limit,1),500))
    if restaurant_id: stmt=stmt.where(AuditLog.restaurant_id==restaurant_id)
    return db.scalars(stmt).all()

def get_platform_settings(db: Session):
    s=db.get(PlatformSetting,1)
    if not s:
        s=PlatformSetting(id=1); db.add(s); db.commit(); db.refresh(s)
    return s

@router.get("/super/settings", response_model=PlatformSettingsOut)
def get_super_settings(db: Session = Depends(get_db), _: User = Depends(require_role(UserRole.SUPER_ADMIN))):
    s=get_platform_settings(db); return s

@router.patch("/super/settings", response_model=PlatformSettingsOut)
def update_super_settings(data: PlatformSettingsUpdate, db: Session = Depends(get_db), admin: User = Depends(require_role(UserRole.SUPER_ADMIN))):
    s=get_platform_settings(db)
    for f in ("platform_name","maintenance_mode","default_currency","allow_new_restaurants"):
        v=getattr(data,f)
        if v is not None: setattr(s,f,v.upper() if f=="default_currency" else v)
    db.add(AuditLog(actor_user_id=admin.id,action="PLATFORM_SETTINGS_UPDATED",metadata_json={"maintenance_mode":s.maintenance_mode,"allow_new_restaurants":s.allow_new_restaurants})); db.commit(); db.refresh(s); return s

# ---- Stage 6: Notifications + Analytics ----
from datetime import datetime, timedelta, timezone
from app.models import Notification
from pydantic import BaseModel, Field

class NotificationOut(BaseModel):
    id: str; type: str; title: str; message: str; payload: dict | None; read_at: str | None; created_at: str
class NotificationReadIn(BaseModel):
    read: bool = True
class RestaurantAnalytics(BaseModel):
    orders_total: int; orders_today: int; revenue_total: int; revenue_today: int
    new_orders: int; preparing_orders: int; completed_orders: int; cancelled_orders: int
    top_items: list[dict]
class PlatformAnalytics(BaseModel):
    orders_today: int; revenue_today: int; active_restaurants: int; blocked_restaurants: int

def _notify_staff(db, restaurant_id, ntype, title, message, payload=None):
    users=db.scalars(select(User).where(User.restaurant_id==restaurant_id, User.active.is_(True), User.role.in_([UserRole.RESTAURANT_OWNER, UserRole.RESTAURANT_ADMIN, UserRole.ORDER_OPERATOR, UserRole.KITCHEN]))).all()
    for u in users:
        db.add(Notification(restaurant_id=restaurant_id,user_id=u.id,type=ntype,title=title,message=message,payload=payload))

def _notification_out(n):
    return NotificationOut(id=n.id,type=n.type,title=n.title,message=n.message,payload=n.payload,read_at=n.read_at.isoformat() if n.read_at else None,created_at=n.created_at.isoformat())

@router.get('/restaurant/notifications', response_model=list[NotificationOut])
def notifications(limit:int=50, unread_only:bool=False, db:Session=Depends(get_db), user:User=Depends(require_role(UserRole.RESTAURANT_OWNER,UserRole.RESTAURANT_ADMIN,UserRole.ORDER_OPERATOR,UserRole.KITCHEN))):
    stmt=select(Notification).where(Notification.restaurant_id==user.restaurant_id, Notification.user_id==user.id).order_by(Notification.created_at.desc()).limit(min(max(limit,1),100))
    if unread_only: stmt=stmt.where(Notification.read_at.is_(None))
    return [_notification_out(n) for n in db.scalars(stmt).all()]

@router.patch('/restaurant/notifications/{notification_id}', response_model=NotificationOut)
def mark_notification(notification_id:str, data:NotificationReadIn, db:Session=Depends(get_db), user:User=Depends(require_role(UserRole.RESTAURANT_OWNER,UserRole.RESTAURANT_ADMIN,UserRole.ORDER_OPERATOR,UserRole.KITCHEN))):
    n=db.get(Notification,notification_id)
    if not n or n.user_id!=user.id or n.restaurant_id!=user.restaurant_id: raise HTTPException(status_code=404,detail='NOTIFICATION_NOT_FOUND')
    n.read_at=datetime.now(timezone.utc) if data.read else None; db.commit(); db.refresh(n); return _notification_out(n)

@router.get('/restaurant/analytics', response_model=RestaurantAnalytics)
def restaurant_analytics(days:int=30, db:Session=Depends(get_db), user:User=Depends(require_role(*ADMIN_ROLES))):
    rid=restaurant_admin(user).restaurant_id; ensure_restaurant_available(db.get(Restaurant,rid)); days=min(max(days,1),365)
    since=datetime.now(timezone.utc)-timedelta(days=days); today=datetime.now(timezone.utc).date()
    base=select(Order).where(Order.restaurant_id==rid, Order.created_at>=since)
    orders=db.scalars(base).all(); all_orders=db.scalars(select(Order).where(Order.restaurant_id==rid)).all()
    today_orders=[o for o in all_orders if o.created_at.date()==today]
    revenue_total=sum(o.total for o in orders if o.status!='cancelled'); revenue_today=sum(o.total for o in today_orders if o.status!='cancelled')
    counts={s:sum(1 for o in all_orders if o.status==s) for s in ['new','preparing','completed','cancelled']}
    rows=db.execute(select(OrderItem.name_snapshot, func.sum(OrderItem.quantity).label('qty')).join(Order,Order.id==OrderItem.order_id).where(Order.restaurant_id==rid,Order.created_at>=since,Order.status!='cancelled').group_by(OrderItem.name_snapshot).order_by(desc('qty')).limit(10)).all()
    return RestaurantAnalytics(orders_total=len(orders),orders_today=len(today_orders),revenue_total=revenue_total,revenue_today=revenue_today,new_orders=counts['new'],preparing_orders=counts['preparing'],completed_orders=counts['completed'],cancelled_orders=counts['cancelled'],top_items=[{'name':r[0],'quantity':int(r[1])} for r in rows])

@router.get('/super/analytics', response_model=PlatformAnalytics)
def platform_analytics(db:Session=Depends(get_db), _:User=Depends(require_role(UserRole.SUPER_ADMIN))):
    today=datetime.now(timezone.utc).date(); orders=db.scalars(select(Order)).all(); today_orders=[o for o in orders if o.created_at.date()==today and o.status!='cancelled']
    return PlatformAnalytics(orders_today=len(today_orders),revenue_today=sum(o.total for o in today_orders),active_restaurants=db.scalar(select(func.count()).select_from(Restaurant).where(Restaurant.status==RestaurantStatus.ACTIVE)) or 0,blocked_restaurants=db.scalar(select(func.count()).select_from(Restaurant).where(Restaurant.status==RestaurantStatus.BLOCKED)) or 0)
