from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text
from app.api.routes import router
from app.db.session import SessionLocal
from app.security_middleware import SecurityMiddleware
from app.config import settings
import os

app = FastAPI(title="QR Restaurant Platform API", version="1.0.0")
origins=[x.strip() for x in os.getenv('CORS_ORIGINS','').split(',') if x.strip()]
if origins:
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=['GET','POST','PATCH','PUT','DELETE','OPTIONS'], allow_headers=['Authorization','Content-Type','Idempotency-Key'])
app.add_middleware(SecurityMiddleware, max_requests=int(os.getenv('RATE_LIMIT_REQUESTS','120')), window_seconds=int(os.getenv('RATE_LIMIT_WINDOW','60')))
app.include_router(router)

@app.get('/api/v1/health/live')
def live(): return {'ok':True,'status':'live'}

@app.get('/api/v1/health/ready')
def ready():
    db=SessionLocal()
    try:
        db.execute(text('SELECT 1'))
        return {'ok':True,'status':'ready','database':'ok'}
    except Exception:
        from fastapi import HTTPException
        raise HTTPException(status_code=503, detail='DATABASE_NOT_READY')
    finally: db.close()
