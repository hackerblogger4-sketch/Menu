import os, time, uuid
from collections import defaultdict, deque
from fastapi import Request
from fastapi.responses import JSONResponse

class SecurityMiddleware:
    def __init__(self, app, max_requests=120, window_seconds=60, max_body_bytes=2_000_000):
        self.app=app; self.max_requests=max_requests; self.window=window_seconds; self.max_body=max_body_bytes
        self.hits=defaultdict(deque)
    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http': return await self.app(scope, receive, send)
        request=Request(scope, receive=receive)
        request_id=str(uuid.uuid4())
        if request.method in {'POST','PUT','PATCH'}:
            cl=request.headers.get('content-length')
            if cl and int(cl)>self.max_body: return await JSONResponse({'detail':'REQUEST_TOO_LARGE'},status_code=413,headers={'X-Request-ID':request_id})(scope,receive,send)
        ip=request.client.host if request.client else 'unknown'; now=time.monotonic(); q=self.hits[ip]
        while q and now-q[0]>self.window: q.popleft()
        if len(q)>=self.max_requests and request.url.path not in {'/api/v1/health','/api/v1/health/live','/api/v1/health/ready'}:
            return await JSONResponse({'detail':'RATE_LIMITED'},status_code=429,headers={'Retry-After':str(self.window),'X-Request-ID':request_id})(scope,receive,send)
        q.append(now)
        async def send_wrapper(message):
            if message['type']=='http.response.start':
                h=message.setdefault('headers',[])
                h.extend([(b'x-request-id',request_id.encode()),(b'x-content-type-options',b'nosniff'),(b'x-frame-options',b'DENY'),(b'referrer-policy',b'no-referrer'),(b'permissions-policy',b'camera=(), microphone=(), geolocation=()'),(b'cache-control',b'no-store')])
                if os.getenv('ENVIRONMENT','production')=='production': h.append((b'strict-transport-security',b'max-age=31536000; includeSubDomains'))
            await send(message)
        return await self.app(scope, receive, send_wrapper)
