from pathlib import Path

def test_stage6_files_present():
    assert Path('database/migrations/versions/0004_notifications.py').exists()
    assert 'class Notification' in Path('backend/app/models/models.py').read_text()
    routes=Path('backend/app/api/routes.py').read_text()
    assert '/restaurant/notifications' in routes
    assert '/restaurant/analytics' in routes
    assert '/super/analytics' in routes

def test_stage7_hardening_present():
    assert Path('backend/app/security_middleware.py').exists()
    assert Path('docker-compose.prod.yml').exists()
    assert Path('infra/nginx/nginx.conf').exists()
    assert Path('scripts/backup_postgres.sh').exists()
