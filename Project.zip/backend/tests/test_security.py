from app.auth.security import hash_password, verify_password, create_access_token, decode_token

def test_password_hash():
    h=hash_password('secret'); assert h!='secret'; assert verify_password('secret',h); assert not verify_password('wrong',h)

def test_token():
    t=create_access_token('abc'); assert decode_token(t)['sub']=='abc'
