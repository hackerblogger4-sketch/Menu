"""stage 3 orders and order items

Revision ID: 0002_orders
Revises: 0001_initial
"""
from alembic import op
import sqlalchemy as sa

revision = "0002_orders"
down_revision = "0001_initial"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("orders", sa.Column("order_number", sa.Integer(), nullable=True))
    op.add_column("orders", sa.Column("idempotency_key", sa.String(length=128), nullable=True))
    bind = op.get_bind()
    rows = bind.execute(sa.text("SELECT id, restaurant_id FROM orders ORDER BY created_at, id")).fetchall()
    counters = {}
    for row in rows:
        counters[row.restaurant_id] = counters.get(row.restaurant_id, 0) + 1
        bind.execute(sa.text("UPDATE orders SET order_number=:n WHERE id=:id"), {"n": counters[row.restaurant_id], "id": row.id})
    op.alter_column("orders", "order_number", nullable=False)
    op.create_index("ix_orders_idempotency_key", "orders", ["idempotency_key"])
    op.create_unique_constraint("uq_order_restaurant_number", "orders", ["restaurant_id", "order_number"])
    op.create_unique_constraint("uq_order_restaurant_idempotency", "orders", ["restaurant_id", "idempotency_key"])

    op.create_table(
        "order_items",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("order_id", sa.String(length=36), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("menu_item_id", sa.String(length=36), sa.ForeignKey("menu_items.id"), nullable=False),
        sa.Column("name_snapshot", sa.String(length=200), nullable=False),
        sa.Column("unit_price", sa.BigInteger(), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False),
        sa.Column("subtotal", sa.BigInteger(), nullable=False),
    )
    op.create_index("ix_order_items_order_id", "order_items", ["order_id"])

def downgrade():
    op.drop_index("ix_order_items_order_id", table_name="order_items")
    op.drop_table("order_items")
    op.drop_constraint("uq_order_restaurant_idempotency", "orders", type_="unique")
    op.drop_constraint("uq_order_restaurant_number", "orders", type_="unique")
    op.drop_index("ix_orders_idempotency_key", table_name="orders")
    op.drop_column("orders", "idempotency_key")
    op.drop_column("orders", "order_number")
