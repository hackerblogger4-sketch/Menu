"""stage 6 notifications
Revision ID: 0004_notifications
Revises: 0003_admin_super_admin
"""
from alembic import op
import sqlalchemy as sa

revision='0004_notifications'; down_revision='0003_admin_super_admin'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('notifications',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('restaurant_id', sa.String(36), sa.ForeignKey('restaurants.id', ondelete='CASCADE'), nullable=False, index=True),
        sa.Column('user_id', sa.String(36), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=True, index=True),
        sa.Column('type', sa.String(50), nullable=False),
        sa.Column('title', sa.String(200), nullable=False),
        sa.Column('message', sa.Text(), nullable=False),
        sa.Column('payload', sa.JSON(), nullable=True),
        sa.Column('read_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_notifications_user_unread', 'notifications', ['user_id','read_at'])

def downgrade():
    op.drop_index('ix_notifications_user_unread', table_name='notifications')
    op.drop_table('notifications')
