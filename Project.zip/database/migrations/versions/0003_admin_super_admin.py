"""stage 4 restaurant admin and stage 5 super admin settings

Revision ID: 0003_admin_super_admin
Revises: 0002_orders
"""
from alembic import op
import sqlalchemy as sa
revision = "0003_admin_super_admin"
down_revision = "0002_orders"
branch_labels = None
depends_on = None

def upgrade():
    for name, typ in [("phone", sa.String(50)), ("address", sa.Text()), ("logo_url", sa.Text()), ("currency", sa.String(3)), ("default_language", sa.String(10))]:
        op.add_column("restaurants", sa.Column(name, typ, nullable=True))
    op.execute("UPDATE restaurants SET currency='KRW' WHERE currency IS NULL")
    op.execute("UPDATE restaurants SET default_language='ko' WHERE default_language IS NULL")
    op.alter_column("restaurants", "currency", nullable=False, server_default="KRW")
    op.alter_column("restaurants", "default_language", nullable=False, server_default="ko")
    op.create_unique_constraint("uq_table_restaurant_number", "restaurant_tables", ["restaurant_id", "table_number"])
    op.create_table("platform_settings",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("platform_name", sa.String(120), nullable=False, server_default="QR Restaurant"),
        sa.Column("maintenance_mode", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("default_currency", sa.String(3), nullable=False, server_default="KRW"),
        sa.Column("allow_new_restaurants", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False))
    op.execute("INSERT INTO platform_settings (id, platform_name, maintenance_mode, default_currency, allow_new_restaurants, updated_at) VALUES (1, 'QR Restaurant', false, 'KRW', true, NOW())")

def downgrade():
    op.drop_table("platform_settings")
    op.drop_constraint("uq_table_restaurant_number", "restaurant_tables", type_="unique")
    for name in ["default_language", "currency", "logo_url", "address", "phone"]:
        op.drop_column("restaurants", name)
