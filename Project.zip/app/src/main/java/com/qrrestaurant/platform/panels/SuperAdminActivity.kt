package com.qrrestaurant.platform.panels
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.qrrestaurant.platform.databinding.ActivitySuperAdminBinding
class SuperAdminActivity : AppCompatActivity() {
 override fun onCreate(b: Bundle?) { super.onCreate(b); val x=ActivitySuperAdminBinding.inflate(layoutInflater); setContentView(x.root)
  val actions=listOf(x.restaurantsButton to "Restaurant management", x.blockButton to "Block/Unblock", x.auditButton to "Audit logs", x.settingsButton to "Platform settings", x.statsButton to "Platform stats")
  actions.forEach { (button,msg)->button.setOnClickListener{Toast.makeText(this,"$msg: API bilan ulanadi",Toast.LENGTH_SHORT).show()} }
 }
}
