package com.qrrestaurant.platform.panels
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.qrrestaurant.platform.databinding.ActivityAdminBinding
class RestaurantAdminActivity : AppCompatActivity() {
 override fun onCreate(b: Bundle?) { super.onCreate(b); val x=ActivityAdminBinding.inflate(layoutInflater); setContentView(x.root)
  val actions=listOf(x.menuButton to "Menu CRUD", x.tableButton to "Table + QR CRUD", x.staffButton to "Staff/RBAC", x.settingsButton to "Restaurant settings", x.statsButton to "Restaurant stats")
  actions.forEach { (button,msg)->button.setOnClickListener{Toast.makeText(this,"$msg: API bilan ulanadi",Toast.LENGTH_SHORT).show()} }
 }
}
