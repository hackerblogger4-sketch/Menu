package com.qrrestaurant.platform
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.qrrestaurant.platform.databinding.ActivityMainBinding
import com.qrrestaurant.platform.panels.*
class MainActivity : AppCompatActivity() { override fun onCreate(b: Bundle?) { super.onCreate(b); val x=ActivityMainBinding.inflate(layoutInflater); setContentView(x.root); x.customerButton.setOnClickListener{startActivity(Intent(this,CustomerMenuActivity::class.java))}; x.orderButton.setOnClickListener{startActivity(Intent(this,OrderPanelActivity::class.java))}; x.adminButton.setOnClickListener{startActivity(Intent(this,RestaurantAdminActivity::class.java))}; x.superAdminButton.setOnClickListener{startActivity(Intent(this,SuperAdminActivity::class.java))} } }
