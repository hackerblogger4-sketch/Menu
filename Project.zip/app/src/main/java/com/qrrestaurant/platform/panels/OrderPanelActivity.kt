package com.qrrestaurant.platform.panels

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.qrrestaurant.platform.Config
import com.qrrestaurant.platform.databinding.ActivityPanelBinding

class OrderPanelActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPanelBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPanelBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.title.text = "3. Order Panel"
        binding.description.text = "NEW → ACCEPTED → PREPARING → READY → DELIVERED → COMPLETED.\nWebSocket orqali yangi buyurtmalar real vaqtga yaqin olinadi."
        binding.connection.text = "API: ${Config.API_BASE_URL}\nWebSocket: ${Config.WS_BASE_URL}"
        binding.orders.text = "Buyurtmalar serverdagi /restaurant/orders endpointidan olinadi.\n\nEslatma: autentifikatsiya tokeni ulangan staff sessiyasidan beriladi."
        binding.refresh.setOnClickListener { binding.orders.text = "Yangilash uchun staff token bilan API chaqiruvi kerak. Backend Stage 3 tayyor." }
    }
}
