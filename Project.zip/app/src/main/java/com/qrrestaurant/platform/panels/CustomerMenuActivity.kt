package com.qrrestaurant.platform.panels

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.qrrestaurant.platform.databinding.ActivityPanelBinding

class CustomerMenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityPanelBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val token = intent?.data?.getQueryParameter("token")
        binding.title.text = "Customer Menu"
        binding.description.text = if (token.isNullOrBlank()) {
            "QR kodni skaner qiling. Keyingi UI bosqichida haqiqiy menyu API'dan yuklanadi."
        } else {
            "QR token qabul qilindi: $token\nAPI orqali restoran va stol menyusi olinadi."
        }
    }
}
