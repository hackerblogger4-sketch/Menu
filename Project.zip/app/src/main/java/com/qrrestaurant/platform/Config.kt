package com.qrrestaurant.platform
object Config { const val API_BASE_URL = "https://api.example.com/api/v1"
    const val WS_BASE_URL = "wss://api.example.com/api/v1/restaurant/orders/ws"; const val APP_VERSION = "0.1.0"; const val DEFAULT_LANGUAGE = "ko"; const val DEFAULT_CURRENCY = "KRW" }
