# Lagan QR Android

GitHub-ready Android project for the Lagan QR restaurant system.

## Panels
- Customer / Menu
- Buyurtma paneli
- Restaurant Admin
- Super Admin / Developer

## GitHub -> APK
1. Extract this ZIP.
2. Upload the extracted project contents to the root of your GitHub repository.
3. Commit to `main`.
4. Open **Actions** -> **Build Android APK**.
5. When the workflow finishes, open the run and download the **Lagan-QR-debug** artifact.

The included workflow builds the debug APK automatically, so no Gradle installation is required on your PC for the GitHub build.

## Android Studio
Open the extracted folder in Android Studio and let Gradle sync.

## QR deep link
Demo format:
`https://menu.example.com/menu?restaurant=lagan&table=12`

Replace the example domain with the real production domain before release.
