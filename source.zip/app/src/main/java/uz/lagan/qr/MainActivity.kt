@file:OptIn(ExperimentalMaterial3Api::class)
package uz.lagan.qr

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class MenuItem(
    val id: String,
    val name: String,
    val description: String,
    val price: Long
)

private val demoMenu = listOf(
    MenuItem("osh", "O‘zbek oshi", "Qo‘y go‘shti, sabzi, no‘xat", 35000),
    MenuItem("lagman", "Lag‘mon", "Qo‘lda cho‘zilgan noodle va go‘sht", 32000),
    MenuItem("achichuk", "Achichuk", "Pomidor va piyozli salat", 12000),
    MenuItem("tea", "Ko‘k choy", "An’anaviy choynak", 6000),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LaganApp(parseQrIntent(intent))
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }
}

private fun parseQrIntent(intent: Intent?): Pair<String?, String?> {
    val uri: Uri = intent?.data ?: return null to null
    return uri.getQueryParameter("restaurant") to uri.getQueryParameter("table")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LaganApp(context: Pair<String?, String?>) {
    var panel by remember { mutableStateOf("Menyu") }
    var cart by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    val (restaurant, table) = context

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Lagan QR") }) }
        ) { padding ->
            when (panel) {
                "Menyu" -> CustomerMenu(
                    restaurant = restaurant ?: "demo",
                    table = table ?: "1",
                    cart = cart,
                    modifier = Modifier.padding(padding),
                    onAdd = { id ->
                        cart = cart + (id to ((cart[id] ?: 0) + 1))
                    },
                    onOpenOrders = { panel = "Buyurtmalar" }
                )
                "Buyurtmalar" -> Panel(
                    title = "Buyurtma paneli",
                    rows = listOf(
                        "Yangi buyurtmalar",
                        "Stol №12 — Osh ×2, Achichuk ×1",
                        "Stol №4 — Lag‘mon ×1"
                    ),
                    onBack = { panel = "Menyu" }
                )
                "Restoran Admin" -> Panel(
                    title = "Restoran Admin",
                    rows = listOf(
                        "Menyu boshqaruvi",
                        "Stollar va QR",
                        "Restoran adminlari",
                        "Statistika"
                    ),
                    onBack = { panel = "Menyu" }
                )
                else -> Panel(
                    title = "Asosiy Admin",
                    rows = listOf(
                        "Restoranlar",
                        "Bloklash / blokdan chiqarish",
                        "Platforma statistikasi",
                        "Audit log",
                        "Dizayn va yangilanishlar"
                    ),
                    onBack = { panel = "Menyu" }
                )
            }
        }
    }
}

@Composable
private fun CustomerMenu(
    restaurant: String,
    table: String,
    cart: Map<String, Int>,
    modifier: Modifier = Modifier,
    onAdd: (String) -> Unit,
    onOpenOrders: () -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Restoran: $restaurant • Stol: $table",
                style = MaterialTheme.typography.titleMedium
            )
        }
        items(demoMenu) { item ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name, style = MaterialTheme.typography.titleMedium)
                        Text(item.description, style = MaterialTheme.typography.bodySmall)
                        Text("${item.price} so‘m")
                    }
                    Button(onClick = { onAdd(item.id) }) { Text("+") }
                }
            }
        }
        item {
            Text("Savat: ${cart.values.sum()} ta")
            Button(
                onClick = onOpenOrders,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Buyurtma paneli (demo)") }
        }
        item {
            OutlinedButton(
                onClick = {},
                modifier = Modifier.fillMaxWidth()
            ) { Text("API bilan ulanish uchun tayyor") }
        }
    }
}

@Composable
private fun Panel(title: String, rows: List<String>, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall)
        rows.forEach { Text("• $it") }
        OutlinedButton(onClick = onBack) { Text("← Menyuga qaytish") }
    }
}
